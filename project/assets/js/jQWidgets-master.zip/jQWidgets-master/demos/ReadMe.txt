Important:

1. To run a sample that includes data binding, you must open it via "http://..." protocol since Ajax makes http requests. 

Please, run any sample on a Localhost or Web Server. 

2. Angular and React demos require the required node_modules to be installed. Within the "angular" and "react" folders, you will find a file called
setup.bat. Double-click on it to automatically install the required node_modules.

