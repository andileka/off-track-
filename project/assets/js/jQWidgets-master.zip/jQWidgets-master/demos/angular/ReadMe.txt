
-----------------------------------------------------------------------
Usage:

Run setup.bat.

- Setup.bat will install all required Node modules and will build one example.
- The example which will be built by running setup.bat is configured in webpack.config0.js.
All other examples are configured in the other webpack.config files.

 
-----------------------------------------------------------------------